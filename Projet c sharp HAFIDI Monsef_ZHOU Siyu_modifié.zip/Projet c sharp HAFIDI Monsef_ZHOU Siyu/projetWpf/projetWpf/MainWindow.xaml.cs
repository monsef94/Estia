﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SQLite.Net;
using SQLite.Net.Platform.Win32;


namespace projetWpf
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private ObservableCollection<Ville> lv = new ObservableCollection<Ville>();
        private ObservableCollection<Resultats> lr = new ObservableCollection<Resultats>();
        private ObservableCollection<Affichage> la = new ObservableCollection<Affichage>();
        //private Params pm = new Params();
        public MainWindow()
        {
            InitializeComponent();
            List<Ville> llv = DAL.getDb().getListVille();
            foreach (Ville v in llv)
            {
                lv.Add(v);
            }
            liste.ItemsSource = lv;
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //lv[0].Name = "TOTO";
            Ville v = new Ville(Box1.Text, Int32.Parse(Box2.Text), Int32.Parse(Box3.Text));
            DAL.getDb().insertVille(v);
            lv.Add(v);
        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_2(object sender, TextChangedEventArgs e)
        {

        }
        private void TextBox_TextChanged_3(object sender, TextChangedEventArgs e)
        {

        }
        private void TextBox_TextChanged_4(object sender, TextChangedEventArgs e)
        {

        }
        private void TextBox_TextChanged_5(object sender, TextChangedEventArgs e)
        {

        }
        private void TextBox_TextChanged_6(object sender, TextChangedEventArgs e)
        {

        }
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Params param = new Params(Int32.Parse(Box4.Text), Int32.Parse(Box5.Text), Int32.Parse(Box6.Text));
            Save sv = new Save();
            sv.save(param);
        }
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Ville v = (Ville)liste.SelectedItem;
            DAL.getDb().deleteVille(v);
            lv.Remove(v);

        }
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Config tsp = new Config();
            Chromosome chr = new Chromosome();
            tsp.Initialization();
            tsp.TSPCompute();
            Resultats[] llr = tsp.getRes();
            foreach (Resultats v in llr)
            {
                lr.Add(v);
            }
            res.ItemsSource = lr;
            Affichage[] lla = tsp.getAff();
            foreach (Affichage v in lla)
            {
                la.Add(v);
            }
            Opti.ItemsSource = la;
        }
        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            InitializeComponent();
        }
    }
}
