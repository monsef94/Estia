﻿using SQLite.Net;
using SQLite.Net.Platform.Win32;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;


namespace projetWpf
{
    /// <summary>
    /// Logique d'interaction pour App.xaml
    /// </summary>
    public partial class App : Application
    {
        
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
           //  SQLitePlatformWin32 _platform = new SQLitePlatformWin32();
          //   SQLiteConnection connection = new SQLiteConnection(_platform,"myDB.db30");
           //  connection.CreateTable<Ville>();
           //  connection.Insert(new Ville("bayonne",10,10));
            // List<Ville> cl=connection.Query<Ville>("Select* from Ville");
            // Console.WriteLine(cl[0]);

        }
    }
}
