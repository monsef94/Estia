﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite.Net;
using SQLite.Net.Attributes;

namespace projetWpf
{
    class Params : INotifyPropertyChanged
    {

        public Params(Params param)
        { }
        
        public int Pop { get; set; }
        public int Mut { get; set; }
        public int Cros { get; set; }
        public int getPop()
        {
            return Pop;
        }
        public int getmut()
        {

            return Mut;
        }

        public int getcros()
        {

            return Cros;

        }
        public Params(int p, int m, int c)
        {
            this.Pop = p;
            this.Mut = m;
            this.Cros = c;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged(string propName)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }
    }
}
