﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite.Net;
using SQLite.Net.Attributes;

namespace projetWpf
{
    class Affichage: INotifyPropertyChanged
    {
     public Affichage()
        {

        }
        private string name;
        public string Ordre
        {
            get { return name; }
            set
            {
                name = value;
                NotifyPropertyChanged("Ordre");
            }

        }
    //[MaxLength(50)]
        public Affichage(string a)
        {
            this.Ordre = a;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged(string propName)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }
     }
}
