﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite.Net;
using SQLite.Net.Attributes;

namespace projetWpf
{
    class Resultats : INotifyPropertyChanged
    {
     public Resultats()
        {

        }
        private string name;
        public string G
        {
            get { return name; }
            set
            {
                name = value;
                NotifyPropertyChanged("G");
            }

        }
    //[MaxLength(50)]
        public string C { get; set; }
        public string M { get; set; }
      
        public Resultats(string a, string b, string c)
        {
            this.G = a;
            this.C = b;
            this.M = c;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged(string propName)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }
     }
}

