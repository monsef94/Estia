﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite.Net;
using SQLite.Net.Attributes;

namespace projetWpf
{
    [Table("Ville")]
    class Ville : INotifyPropertyChanged
    {
        public Ville()
        {

        }
        private string name;
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        [Column("Name")]
        public string Name
        {

            get { return name; }
            set
            {
                name = value;
                NotifyPropertyChanged("Name");
            }

        }
    //[MaxLength(50)]
        public int X { get; set; }
        public int Y { get; set; }
        public string getName()
        {
            return Name;
        }
        public int getx()
        {

            return X;
        }

        public int gety()
        {

            return Y;

        }
        public Ville(string v, int x, int y)
        {
            this.Name = v;
            this.X = x;
            this.Y = y;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged(string propName)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }
        public int Distance(int x, int y)
        {
            int xdiff = getx() - x;
            int ydiff = gety() - y;
            return (int)Math.Sqrt(xdiff * xdiff + ydiff * ydiff);
        }
        public int proximity(Ville autreV)
        {

            return Distance(autreV.getx(), autreV.gety());

        }
    }
}
