﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace projetWpf
{
    class Config
    {

        protected int villeCount;

        public int populationSize;

        protected double mutationPercent;

        protected int matingPopulationSize;

        protected int favoredPopulationSize;

        protected int cutLength;

        protected int generation;

        protected Thread worker = null;

        protected bool started = false;

        protected Ville[] villes;

        public Save sv = new Save();

        public Params param;

        public Resultats[] res;
        public Affichage[] Aff;

        

       // public Resultats resu;

        int cpt = 0;


        protected int mutation;

        protected Chromosome[] chromosomes;

        private string status = "";

        public Config()
        {

        }


        public void Initialization()
        {

            Random randObj = new Random();

            try
            {

                villeCount = 5;
                param = sv.getparam();
                populationSize = param.getPop();
                mutation = param.getmut();
                string Stringmutation = "0.0" + mutation.ToString();
                System.Console.WriteLine(Stringmutation);
                mutationPercent = Int32.Parse(Stringmutation);
                System.Console.WriteLine(mutationPercent);

            }

            catch (Exception e)
            {

                villeCount = 5;
                populationSize = 1000;
                mutationPercent = 0.05;

            }

            matingPopulationSize = populationSize / 2;

            favoredPopulationSize = matingPopulationSize / 2;

            cutLength = villeCount / 5;

            // create a random list of cities

            villes = new Ville[villeCount];
            res = new Resultats[300];
            Aff = new Affichage[5];
            

            /*for (int i = 0; i < villeCount; i++)
            {

                villes[i] = new Ville(

                          (int)(randObj.NextDouble() * 30), (int)(randObj.NextDouble() * 15));

            }*/
            List<Ville> llv = DAL.getDb().getListVille();
            for (int i = 0; i < villeCount; i++)
            {
                villes[i] = llv[i];
            }
            // create the initial chromosomes

            chromosomes = new Chromosome[populationSize];

            for (int i = 0; i < populationSize; i++)
            {

                chromosomes[i] = new Chromosome(villes);

                chromosomes[i].assignCut(cutLength);

                chromosomes[i].assignMutation(mutationPercent);

            }

            Chromosome.sortChromosomes(chromosomes, populationSize);

            started = true;

            generation = 0;

        }
        public void TSPCompute()
        {

            double thisCout = 500.0;

            double oldCout = 0.0;

            double dcout = 500.0;

            int countSame = 0;

            Random randObj = new Random();

            while (countSame < 120)
            {

                generation++;

                int ioffset = matingPopulationSize;

                int mutated = 0;

                for (int i = 0; i < favoredPopulationSize; i++)
                {

                    Chromosome cmother = chromosomes[i];

                    int father = (int)(randObj.NextDouble() * (double)matingPopulationSize);

                    Chromosome cfather = chromosomes[father];

                    mutated += cmother.mate(cfather, chromosomes[ioffset], chromosomes[ioffset + 1]);

                    ioffset += 2;

                }

                for (int i = 0; i < matingPopulationSize; i++)
                {

                    chromosomes[i] = chromosomes[i + matingPopulationSize];

                    chromosomes[i].calculateCout(villes);

                }

                // Now sort the new population

                Chromosome.sortChromosomes(chromosomes, matingPopulationSize);

                double cout = chromosomes[0].getCout();

                dcout = Math.Abs(cout - thisCout);

                thisCout = cout;

                double mutationRate = 100.0 * (double)mutated / (double)matingPopulationSize;


                System.Console.WriteLine("Generation = " + generation.ToString() + " Cout = " + thisCout.ToString() + " taux de mutation = " + mutationRate.ToString() + "%");
                string g=generation.ToString();
                string c=thisCout.ToString();
                string m=mutationRate.ToString();
                res[cpt]=new Resultats(g,c,m);
                cpt++;

                if ((int)thisCout == (int)oldCout)
                {

                    countSame++;

                }

                else
                {

                    countSame = 0;

                    oldCout = thisCout;

                    //System.Console.WriteLine("oldCost = " + oldCost.ToString());

                }

            }

            for (int i = 0; i < villes.Length; i++)
            {

                chromosomes[i].PrintVille(i, villes);
                string azerty = "Ville " + i.ToString() + ": " + villes[chromosomes[i].villeList[i]].getName() + " (" + villes[chromosomes[i].villeList[i]].getx().ToString() + ", " + villes[chromosomes[i].villeList[i]].gety().ToString() + ")";
                Aff[i] = new Affichage(azerty);  


            }
        }
        public Resultats[] getRes(){
                return res;
            }
        public Affichage[] getAff()
        {
                return Aff;
        }
    }

}