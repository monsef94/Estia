﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projetWpf
{
    class Save
    {
        public Save()
        {
        }
        public Params Param;
        public void save(Params p)
        {
            this.Param = p;
        }
        public Params getparam(){
            return Param;
        }
            
    }
}
