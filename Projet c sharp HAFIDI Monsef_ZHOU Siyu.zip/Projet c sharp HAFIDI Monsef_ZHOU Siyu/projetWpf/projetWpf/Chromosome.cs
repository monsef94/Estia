﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projetWpf
{
    class Chromosome
    {
        public Chromosome()
        {
        }
        //  Le coût de la forme physique du chromosome

        protected double cout;

        Random randObj = new Random();

        //City myCity = new City();

        // La liste des villes qui sont les gènes du chromosome

        public int[] villeList;

        // Le taux de mutation en pourcentage.

        protected double mutationPercent;

        // point de croisement.

        protected int crossoverPoint;
        
        public Affichage[] aff;

        public Chromosome(Ville[] villes)
        {

            bool[] taken = new bool[villes.Length];

            villeList = new int[villes.Length];

            aff = new Affichage[5];

            cout = 0.0;

            for (int i = 0; i < villeList.Length; i++) taken[i] = false;

            for (int i = 0; i < villeList.Length - 1; i++)
            {

                int icandidate;

                do
                {

                    icandidate = (int)(randObj.NextDouble() * (double)villeList.Length);

                } while (taken[icandidate]);

                villeList[i] = icandidate;

                taken[icandidate] = true;

                if (i == villeList.Length - 2)
                {

                    icandidate = 0;

                    while (taken[icandidate]) icandidate++;

                    villeList[i + 1] = icandidate;

                }

            }

            calculateCout(villes);

            crossoverPoint = 1;

        }


        // calcul de fitness

        //void calculateCout(myCity cities)

        public void calculateCout(Ville[] villes)
        {

            cout = 0;

            for (int i = 0; i < villeList.Length - 1; i++)
            {

                double dist = villes[villeList[i]].proximity(villes[villeList[i + 1]]);

                cout += dist;

            }

        }



        public double getCout()
        {

            return cout;

        }



        public int getVille(int i)
        {

            return villeList[i];

        }

       

        public void assignVilles(int[] list)
        {

            for (int i = 0; i < villeList.Length; i++)
            {

                villeList[i] = list[i];

            }

        }



        public void assignville(int index, int value)
        {

            villeList[index] = value;

        }



        public void assignCut(int cut)
        {

            crossoverPoint = cut;

        }



        public void assignMutation(double prob)
        {

            mutationPercent = prob;

        }



        public int mate(Chromosome father, Chromosome offspring1, Chromosome offspring2)
        {

            int crossoverPostion1 = (int)((randObj.NextDouble()) * (double)(villeList.Length - crossoverPoint));

            int crossoverPostion2 = crossoverPostion1 + crossoverPoint;

            int[] offset1 = new int[villeList.Length];

            int[] offset2 = new int[villeList.Length];

            bool[] taken1 = new bool[villeList.Length];

            bool[] taken2 = new bool[villeList.Length];

            for (int i = 0; i < villeList.Length; i++)
            {

                taken1[i] = false;

                taken2[i] = false;

            }

            for (int i = 0; i < villeList.Length; i++)
            {

                if (i < crossoverPostion1 || i >= crossoverPostion2)
                {

                    offset1[i] = -1;

                    offset2[i] = -1;

                }

                else
                {

                    int imother = villeList[i];

                    int ifather = father.getVille(i);

                    offset1[i] = ifather;

                    offset2[i] = imother;

                    taken1[ifather] = true;

                    taken2[imother] = true;

                }

            }

            for (int i = 0; i < crossoverPostion1; i++)
            {

                if (offset1[i] == -1)
                {

                    for (int j = 0; j < villeList.Length; j++)
                    {

                        int imother = villeList[j];

                        if (!taken1[imother])
                        {

                            offset1[i] = imother;

                            taken1[imother] = true;

                            break;

                        }

                    }

                }

                if (offset2[i] == -1)
                {

                    for (int j = 0; j < villeList.Length; j++)
                    {

                        int ifather = father.getVille(j);

                        if (!taken2[ifather])
                        {

                            offset2[i] = ifather;

                            taken2[ifather] = true;

                            break;

                        }

                    }

                }

            }

            for (int i = villeList.Length - 1; i >= crossoverPostion2; i--)
            {

                if (offset1[i] == -1)
                {

                    for (int j = villeList.Length - 1; j >= 0; j--)
                    {

                        int imother = villeList[j];

                        if (!taken1[imother])
                        {

                            offset1[i] = imother;

                            taken1[imother] = true;

                            break;

                        }

                    }

                }

                if (offset2[i] == -1)
                {

                    for (int j = villeList.Length - 1; j >= 0; j--)
                    {

                        int ifather = father.getVille(j);

                        if (!taken2[ifather])
                        {

                            offset2[i] = ifather;

                            taken2[ifather] = true;

                            break;

                        }

                    }

                }

            }

            offspring1.assignVilles(offset1);

            offspring2.assignVilles(offset2);

            int mutate = 0;

            int swapPoint1 = 0;

            int swapPoint2 = 0;

            if (randObj.NextDouble() < mutationPercent)
            {

                swapPoint1 = (int)(randObj.NextDouble() * (double)(villeList.Length));

                swapPoint2 = (int)(randObj.NextDouble() * (double)villeList.Length);

                int i = offset1[swapPoint1];

                offset1[swapPoint1] = offset1[swapPoint2];

                offset1[swapPoint2] = i;

                mutate++;

            }

            if (randObj.NextDouble() < mutationPercent)
            {

                swapPoint1 = (int)(randObj.NextDouble() * (double)(villeList.Length));

                swapPoint2 = (int)(randObj.NextDouble() * (double)(villeList.Length));

                int i = offset2[swapPoint1];

                offset2[swapPoint1] = offset2[swapPoint2];

                offset2[swapPoint2] = i;

                mutate++;

            }

            return mutate;

        }

        public void PrintVille(int i, Ville[] villes)
        {

            System.Console.WriteLine("Ville " + i.ToString() + ": "+villes[villeList[i]].getName()+" (" + villes[villeList[i]].getx().ToString() + ", "

              + villes[villeList[i]].gety().ToString() + ")");

            string azerty = "Ville " + i.ToString() + ": " + villes[villeList[i]].getName() + " (" + villes[villeList[i]].getx().ToString() + ", " + villes[villeList[i]].gety().ToString() + ")";
            aff[i] = new Affichage(azerty);         

    
        }

        // chromosomes - un tableau de chromosomes qui est trié

        // num - le numéro de la liste des chromosomes
        public Affichage[] getaff()
        {
            return aff;
        }

        public static void sortChromosomes(Chromosome[] chromosomes, int num)
        {

            bool swapped = true;

            Chromosome dummy;

            while (swapped)
            {

                swapped = false;

                for (int i = 0; i < num - 1; i++)
                {

                    if (chromosomes[i].getCout() > chromosomes[i + 1].getCout())
                    {

                        dummy = chromosomes[i];

                        chromosomes[i] = chromosomes[i + 1];

                        chromosomes[i + 1] = dummy;

                        swapped = true;

                    }

                }

            }

        }

    }

}


