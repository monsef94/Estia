﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite.Net;
using SQLite.Net.Platform.Win32;

namespace projetWpf
{
    class DAL
    {
        private static DAL db = null;
        public static DAL getDb()
        {
            if (db == null)
            {
                db = new DAL();
            }
            return db;
        }


        SQLiteConnection connection;
        private DAL()
        {
            SQLitePlatformWin32 _platform = new SQLitePlatformWin32();
            connection = new SQLiteConnection(_platform, "myDb.db3");
            connection.CreateTable<Ville>();
        }

        public void insertVille(Ville c)
        {
            connection.Insert(c);
        }

        public void deleteVille(Ville c)
        {
            connection.Delete(c);
        }

        public List<Ville> getListVille()
        {
            return connection.Query<Ville>("Select * from Ville");
        } 
    }
}